package Forum_Topic;

import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
public class CreateQAForum_topic {
  @Test
  public void QAForum() {
	  WebDriver driverFF= new FirefoxDriver();
		
		driverFF.navigate().to("https://qa.engagelms.com/learn/my/");

		WebElement Element1 = driverFF.findElement(By.xpath("//*[@id='username']"));
		WebElement Element2 = driverFF.findElement(By.xpath("//*[@id='password']"));
		WebElement Element3 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));

		Element1.sendKeys("autofaculty01");
		Element2.sendKeys("autoqa1+");
		Element3.click();
		driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		driverFF.manage().window().maximize();
		
		if (driverFF.getPageSource().contains("Debug")) 
		   {
		  	 System.out.println("ERROR");
		  	
		   }
		   if (driverFF.getPageSource().contains("Stack trace")) 
		   {
		  	 System.out.println("ERROR");
		  	
		   }
		WebElement Element4 = driverFF.findElement(By.xpath("//*[@id='inst2603']/div[2]/div[2]/div[1]/a/h2"));
		Element4.click();
		WebElement Element5 = driverFF.findElement(By.xpath("html/body/header/nav/div/div/ul[2]/li[3]/div/form/div/input[1]"));
		Element5.click();
		  WebElement Element7 = driverFF.findElement(By.xpath("//*[@id='section-0']/div[3]/div[4]/div/div/span/a/span"));
	    Element7.click();
	    try {
	        Thread.sleep(5000);
	    } catch (InterruptedException e) {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	    }
	    WebElement Element8 = driverFF.findElement(By.xpath("//*[@id='module_forum']"));
	    Element8.click();
	    try {
	        Thread.sleep(5000);
	    } catch (InterruptedException e) {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	    }
	    WebElement Element9 = driverFF.findElement(By.xpath("//*[@id='chooserform']/div[3]/input[1]"));
	    Element9.click();
	    driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	    WebElement Element10 = driverFF.findElement(By.xpath("//*[@id='id_name']"));
	    Element10.sendKeys("Automated_QA_Forum");
	   String str = driverFF.switchTo().frame("id_introeditor_ifr").getTitle();
	   
	    System.out.println("Its Called :" + str);
	    
	    WebElement Element11 = driverFF.findElement(By.id("tinymce"));
	    Element11.sendKeys(" Q A Forum ");
	    driverFF.switchTo().defaultContent();
	    
		WebElement Element12= driverFF.findElement(By.xpath("//*[@id='id_type']"));
		Select clickThis = new Select(Element12); 
		// Make a Selection from the listbox here, this test is to test for 6 topics in the course.
		clickThis.selectByIndex(2);
		WebElement Element13 = driverFF.findElement(By.xpath("//*[@id='id_submitbutton2']"));
	    Element13.click();
	   
	    driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	    WebElement Element14 = driverFF.findElement(By.xpath("//span[contains(., 'Automated_QA_Forum')]"));
	    Boolean B= Element14.isDisplayed();
	    System.out.println(B);
	    
	    /* Login as Student and Verify the New Forum is created */
	    WebElement Element18 = driverFF.findElement(By.xpath("//*[@id='profile_menu']/ul/li/a"));
	 	Element18.click();
	 	
	 	WebElement Element19 = driverFF.findElement(By.xpath("html/body/header/nav/div/div/ul[2]/li[4]/ul/li/ul/li[1]/a"));
	 	Element19.click();
	 	driverFF.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
	 	WebElement Element20 = driverFF.findElement(By.xpath("/html/body/header/nav/div/div/ul/li[2]/a"));
	 	Element20.click();
	 	driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	 	WebElement Element21 = driverFF.findElement(By.xpath("//*[@id='username']"));
	 	WebElement Element22 = driverFF.findElement(By.xpath("//*[@id='password']"));
	 	WebElement Element23 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));
	 	Element21.sendKeys("autostudent01");
	 	Element22.sendKeys("autoqa1+");
	 	Element23.click();
	 	WebElement Element24 = driverFF.findElement(By.xpath("//*[@id='inst714']/div[2]/div[2]/div[1]/a/h2"));
	 	Element24.click();
	 	WebElement Element27 = driverFF.findElement(By.xpath("//*[@id='section-0']/div[3]/h3"));
	 	Element27.click();
	     WebElement Element25 = driverFF.findElement(By.xpath("//span[contains(., 'Automated_QA_Forum')]"));
	     Boolean B1= Element25.isDisplayed();
	     if(B1 == true)
	     {System.out.println("Verified");}
	     Element25.click();
	     driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	     driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	     Boolean QAForum = driverFF.getPageSource().contains("This is a question and answer forum. In order to see other responses to these questions, you must first post your answer");
	     if (QAForum == true)
	     {System.out.println("Its a Q A Forum!- Verified ");}
	     driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	     driverFF.close();
	     
  }
}
