package forum_Accordion;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class EditSettings {
  @Test
  public void LoginAsAdmin() {
	  System.out.println("Test");
	  WebDriver driverFF= new FirefoxDriver();
		
			driverFF.navigate().to("https://qa.engagelms.com/learn/my/");

			WebElement Element1 = driverFF.findElement(By.xpath("//*[@id='username']"));
			WebElement Element2 = driverFF.findElement(By.xpath("//*[@id='password']"));
			WebElement Element3 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));

			Element1.sendKeys("priya");
			Element2.sendKeys("Tushar30");
			Element3.click();
			driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			WebElement Element4= driverFF.findElement(By.xpath("//*[@id='inst2513']/div[2]/div/div[1]/a/h2"));
			Element4.click();
			driverFF.manage().window().maximize();
			driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
				
			WebElement Element5= driverFF.findElement(By.xpath("//*[@id='settingsnav']/ul/li[1]/ul/li[2]/p/a"));
			Element5.click();
			WebElement Element6= driverFF.findElement(By.xpath("html/body/div[2]/div/section/div[2]/form/fieldset[3]/legend/a"));
			Element6.click();
			
			WebElement Element7= driverFF.findElement(By.xpath("//*[@id='id_numsections']"));
			Select clickThis = new Select(Element7); 
			// Make a Selection from the listbox here, this test is to test for 6 topics in the course.
			clickThis.selectByValue("5");
			WebElement Element8= driverFF.findElement(By.xpath("//*[@id='id_submitbutton']"));
			Element8.click();
			driverFF.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			WebElement Element9= driverFF.findElement(By.xpath("//*[@id='section-5']/div[3]/h3"));
			Element9.isDisplayed();
			Element9.isEnabled();
			
			driverFF.quit();

  }
  @BeforeMethod
  public void beforeMethod() {
  }

  @AfterMethod
  public void afterMethod() {
  }

}
