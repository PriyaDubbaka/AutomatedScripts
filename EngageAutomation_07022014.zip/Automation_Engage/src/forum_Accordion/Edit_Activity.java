package forum_Accordion;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Edit_Activity {
  @Test
  public void Faculty_Login_Edit() {
	  WebDriver driverFF= new FirefoxDriver();
		
		driverFF.navigate().to("https://qa.engagelms.com/learn/my/");

		WebElement Element1 = driverFF.findElement(By.xpath("//*[@id='username']"));
		WebElement Element2 = driverFF.findElement(By.xpath("//*[@id='password']"));
		WebElement Element3 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));

		Element1.sendKeys("autofaculty01");
		Element2.sendKeys("autoqa1+");
		Element3.click();
		driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		driverFF.manage().window().maximize();
		WebElement Element4 = driverFF.findElement(By.xpath("//*[@id='inst2603']/div[2]/div[1]/div[1]/a/h2"));
		Element4.click();
		WebElement Element5 = driverFF.findElement(By.xpath("html/body/header/nav/div/div/ul[2]/li[3]/div/form/div/input[1]"));
		Element5.click();
		driverFF.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		WebElement Element6 = driverFF.findElement(By.xpath("//*[@id='action-menu-toggle-10']"));
		Element6.click();
		driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		WebElement Element7 = driverFF.findElement(By.xpath("//*[@id='actionmenuaction-66']"));
		Element7.click();
		driverFF.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//*[@id='id_name']
		
		WebElement Element8 = driverFF.findElement(By.xpath("//*[@id='id_name']"));
		Element8.clear();
		Element8.sendKeys("Edited by Automation");
		 String str = driverFF.switchTo().frame("id_introeditor_ifr").getTitle();
		   
		    System.out.println("Its Called :" + str);
		    
		    WebElement Element9 = driverFF.findElement(By.id("tinymce"));
		    Element9.sendKeys("Content Edited by Automation");
		    driverFF.switchTo().defaultContent();
		    WebElement Element10 = driverFF.findElement(By.xpath("//*[@id='id_submitbutton2']"));
		    Element10.click();
		    driverFF.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		    WebElement Element14 = driverFF.findElement(By.xpath("//span[contains(., 'Edited by Automation')]"));
		    Boolean B= Element14.isDisplayed();
		    System.out.println(B);
		    
		    
	/* These are some xpaths	//*[@id='action-menu-toggle-6']//*[@id='module-16006']
		  //*[@id='actionmenuaction-32']- Duplicate Option     */
		    WebElement Element18 = driverFF.findElement(By.xpath("//*[@id='profile_menu']/ul/li/a"));
			Element18.click();
			WebElement Element19 = driverFF.findElement(By.xpath("html/body/header/nav/div/div/ul[2]/li[4]/ul/li/ul/li[1]/a"));
			Element19.click();
			driverFF.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
			WebElement Element20 = driverFF.findElement(By.xpath("/html/body/header/nav/div/div/ul/li[2]/a"));
			Element20.click();
			driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			WebElement Element21 = driverFF.findElement(By.xpath("//*[@id='username']"));
			WebElement Element22 = driverFF.findElement(By.xpath("//*[@id='password']"));
			WebElement Element23 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));
			Element21.sendKeys("autostudent01");
			Element22.sendKeys("autoqa1+");
			Element23.click();
			WebElement Element24 = driverFF.findElement(By.xpath("//*[@id='inst714']/div[2]/div[1]/div[1]/a/h2"));
			Element24.click();
			 driverFF.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			 WebElement Element27 = driverFF.findElement(By.xpath("//*[@id='section-0']/div[3]/h3"));
			 	Element27.click();
			 	driverFF.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			    WebElement Element25 = driverFF.findElement(By.xpath("//span[contains(., 'Edited by Automation')]"));
			    Boolean B1= Element25.isDisplayed();
			    System.out.println(B1);
			    if (B1 == true)
			    {
			    	System.out.println(" Edit Verified");
			    }
  }
  @BeforeMethod
  public void beforeMethod() {
  }

  @AfterMethod
  public void afterMethod() {
  }

}
