package comments_Accordion;

import org.testng.annotations.Test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class FacultyAddComments {
  @Test
  public void AddComments_faculty() {
	  WebDriver driverFF= new FirefoxDriver();
		
		driverFF.navigate().to("https://qa.engagelms.com/learn/my/");

		WebElement Element1 = driverFF.findElement(By.xpath("//*[@id='username']"));
		WebElement Element2 = driverFF.findElement(By.xpath("//*[@id='password']"));
		WebElement Element3 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));

		Element1.sendKeys("autofaculty01");
		Element2.sendKeys("autoqa1+");
		Element3.click();
		driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		driverFF.manage().window().maximize();
		WebElement Element4 = driverFF.findElement(By.xpath("//*[@id='inst2603']/div[2]/div[1]/div[1]/a/h2"));
		Element4.click();
		WebElement Element41 = driverFF.findElement(By.xpath("html/body/div[2]/div/div/div/section/div[2]/aside/div/div[1]/div/div/img[2]"));
		Element41.click();
		driverFF.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement Element5 = driverFF.findElement(By.xpath("html/body/div[2]/div/div/div/section/div[2]/aside/div/div[2]/div[2]/div/div[1]/div/textarea"));
		Element5.sendKeys("Automated Comments by Faculty");
		WebElement Element6 = driverFF.findElement(By.xpath("html/body/div[2]/div/div/div/section/div[2]/aside/div/div[2]/div[2]/div/div[1]/span/span/a[1]"));
		Element6.click();;
		driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		driverFF.getPageSource().contains("Automated Comments by Faculty");
			 
		 DateFormat dateFormat = new SimpleDateFormat("HH:mm");
		 Date date = new Date();
		 System.out.println(dateFormat.format(date));
	WebElement Element7 = driverFF.findElement(By.xpath("html/body/div[2]/div/div/div/section/div[2]/aside/div/div[2]/div[2]/div/ul/li[2]/div/div[3]/div[1]/a/img"));
			Element7.click();
		WebElement Element8 = driverFF.findElement(By.xpath("html/body/div[3]/div/div/div/a[1]"));
		Element8.click();
		WebElement Element42 = driverFF.findElement(By.xpath("html/body/div[2]/div/div/div/section/div[2]/aside/div/div[1]/div/div/img[1]"));
		Element42.click();
		
		 
  }
}
