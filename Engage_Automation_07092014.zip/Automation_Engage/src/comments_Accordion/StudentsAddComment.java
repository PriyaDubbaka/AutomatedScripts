package comments_Accordion;

import org.testng.annotations.Test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.support.ui.Select;

public class StudentsAddComment {
  @Test
  public void AddComment() {  System.out.println("Just testing");
  WebDriver driverFF= new FirefoxDriver();
	
	driverFF.navigate().to("https://qa.engagelms.com/learn/my/");

	WebElement Element1 = driverFF.findElement(By.xpath("//*[@id='username']"));
	WebElement Element2 = driverFF.findElement(By.xpath("//*[@id='password']"));
	WebElement Element3 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));

	Element1.sendKeys("autostudent01");
	Element2.sendKeys("autoqa1+");
	Element3.click();
	driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	driverFF.manage().window().maximize();
	WebElement Element4 = driverFF.findElement(By.xpath("//*[@id='inst714']/div[2]/div[1]/div[1]/a/h2"));
	Element4.click();
	WebElement Element5 = driverFF.findElement(By.xpath("html/body/div[2]/div/div/div/section/div[2]/aside/div/div[2]/div[2]/div/div[1]/div/textarea"));
	Element5.sendKeys("Automated Comments by Student");
	WebElement Element6 = driverFF.findElement(By.xpath("html/body/div[2]/div/div/div/section/div[2]/aside/div/div[2]/div[2]/div/div[1]/span/span/a[1]"));
	Element6.click();;
	driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	driverFF.getPageSource().contains("Automated Comments by Student");
		 
	 DateFormat dateFormat = new SimpleDateFormat("HH:mm");
	 Date date = new Date();
	 System.out.println(dateFormat.format(date));
	 WebElement Element7 = driverFF.findElement(By.xpath("html/body/div[2]/div/div/div/section/div[2]/aside/div/div[2]/div[2]/div/ul/li[2]/div/div[3]/div[1]/a/img"));
		Element7.click();
		WebElement Element8 = driverFF.findElement(By.xpath("html/body/div[3]/div/div/div/a[1]"));
		Element8.click();
		
  }
}
