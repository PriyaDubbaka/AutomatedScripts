package assignment_Accordion;

import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class NewAssignment {
  @Test
  public void AssignmentCreate_Edit() {
	  WebDriver driverFF= new FirefoxDriver();
		
		driverFF.navigate().to("https://qa.engagelms.com/learn/my/");

		WebElement Element1 = driverFF.findElement(By.xpath("//*[@id='username']"));
		WebElement Element2 = driverFF.findElement(By.xpath("//*[@id='password']"));
		WebElement Element3 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));

		Element1.sendKeys("autofaculty01");
		Element2.sendKeys("autoqa1+");
		Element3.click();
		driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		driverFF.manage().window().maximize();
		WebElement Element4 = driverFF.findElement(By.xpath("//*[@id='inst2603']/div[2]/div[1]/div[1]/a/h2"));
		Element4.click();
		WebElement Element5 = driverFF.findElement(By.xpath("html/body/header/nav/div/div/ul[2]/li[3]/div/form/div/input[1]"));
		Element5.click();
		  WebElement Element7 = driverFF.findElement(By.xpath("//*[@id='section-1']/div[3]/div[2]/div/div/span/a/span"));
	    Element7.click();
	    driverFF.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    WebElement Element8 = driverFF.findElement(By.xpath("//*[@id='module_assign']"));
	    Element8.click();
	    WebElement Element9 = driverFF.findElement(By.xpath("//*[@id='chooserform']/div[3]/input[1]"));
	    Element9.click();
	    driverFF.manage().timeouts().implicitlyWait(9, TimeUnit.SECONDS);
	    WebElement Element10 = driverFF.findElement(By.xpath("//*[@id='id_name']"));
	    Element10.sendKeys("Automated_Assignment");
	   String str = driverFF.switchTo().frame("id_introeditor_ifr").getTitle();
	   
	    System.out.println("Its Called :" + str);
	    
	    WebElement Element11 = driverFF.findElement(By.id("tinymce"));
	    Element11.sendKeys(" Assignment One ");
	    driverFF.switchTo().defaultContent();
	    driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	    //Test Pre-requisites: This test requires an assignment with online text set to yes and file submissions set to no.
	    
	   // Here we check the online text checkbox and uncheck the file submission checkbox
	    
	    WebElement Element121 = driverFF.findElement(By.xpath("//*[@id='id_assignsubmission_onlinetext_enabled']"));
	    Element121.click();
	    driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	    WebElement Element122 = driverFF.findElement(By.xpath("//*[@id='id_assignsubmission_file_enabled']"));
	    Element122.click();
	    driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	    WebElement Element12 = driverFF.findElement(By.xpath("//*[@id='id_submitbutton2']"));
	    Element12.click();
	    driverFF.manage().timeouts().implicitlyWait(9, TimeUnit.SECONDS);
	    WebElement Element18 = driverFF.findElement(By.xpath("//*[@id='profile_menu']/ul/li/a"));
		Element18.click();
		
		WebElement Element19 = driverFF.findElement(By.xpath("html/body/header/nav/div/div/ul[2]/li[4]/ul/li/ul/li[1]/a"));
		Element19.click();
		driverFF.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
		WebElement Element20 = driverFF.findElement(By.xpath("/html/body/header/nav/div/div/ul/li[2]/a"));
		Element20.click();
		driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		WebElement Element21 = driverFF.findElement(By.xpath("//*[@id='username']"));
		WebElement Element22 = driverFF.findElement(By.xpath("//*[@id='password']"));
		WebElement Element23 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));
		Element21.sendKeys("autostudent01");
		Element22.sendKeys("autoqa1+");
		Element23.click();
		WebElement Element24 = driverFF.findElement(By.xpath("//*[@id='inst714']/div[2]/div[1]/div[1]/a/h2"));
		Element24.click();
		WebElement Element27 = driverFF.findElement(By.xpath("//*[@id='section-1']/div[3]/h3"));
	 	Element27.click();
	 	driverFF.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
	    WebElement Element25 = driverFF.findElement(By.xpath("//span[contains(., 'Automated_Assignment')]"));
	    Element25.click();
	    driverFF.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS); 
	    WebElement Element28 = driverFF.findElement(By.xpath(" //*[@id='region-main']/div[2]/div[2]/div[2]/div[1]/form/div/input[1]"));
	    Element28.click();
	    driverFF.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS); 
	    WebElement Element26 = driverFF.findElement(By.xpath(" //*[@id='id_submitbutton']"));
	    Element26.click();
	   Boolean verifyNothingtoSave = driverFF.getPageSource().contains("Nothing was submitted");
	  if (verifyNothingtoSave == true)
	  {System.out.println("Nothing was Submitted Verified");}
	  String str1 = driverFF.switchTo().frame("id_onlinetext_editor_ifr").getTitle();
	   
	    System.out.println("Its Called :" + str1);
	    
	    WebElement Element17 = driverFF.findElement(By.id("tinymce"));
	    Element17.sendKeys(" Automated Assignment Text!! ");
	    driverFF.switchTo().defaultContent();
	    
	    driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	    WebElement Element29 = driverFF.findElement(By.xpath(" //*[@id='id_submitbutton']"));
	    Element29.click();
	  }
}
