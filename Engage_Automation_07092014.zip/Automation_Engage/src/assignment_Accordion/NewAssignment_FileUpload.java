package assignment_Accordion;

import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class NewAssignment_FileUpload {
  @Test
  public void f() {
	  WebDriver driverFF= new FirefoxDriver();
		
			driverFF.navigate().to("https://qa.engagelms.com/learn/my/");

			WebElement Element1 = driverFF.findElement(By.xpath("//*[@id='username']"));
			WebElement Element2 = driverFF.findElement(By.xpath("//*[@id='password']"));
			WebElement Element3 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));

			Element1.sendKeys("autofaculty01");
			Element2.sendKeys("autoqa1+");
			Element3.click();
			driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			driverFF.manage().window().maximize();
			WebElement Element4 = driverFF.findElement(By.xpath("//*[@id='inst2603']/div[2]/div[1]/div[1]/a/h2"));
			Element4.click();
			WebElement Element5 = driverFF.findElement(By.xpath("html/body/header/nav/div/div/ul[2]/li[3]/div/form/div/input[1]"));
			Element5.click();
			  WebElement Element7 = driverFF.findElement(By.xpath("//*[@id='section-1']/div[3]/div[2]/div/div/span/a/span"));
		    Element7.click();
		    driverFF.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		    WebElement Element8 = driverFF.findElement(By.xpath("//*[@id='module_assign']"));
		    Element8.click();
		    WebElement Element9 = driverFF.findElement(By.xpath("//*[@id='chooserform']/div[3]/input[1]"));
		    Element9.click();
		    driverFF.manage().timeouts().implicitlyWait(9, TimeUnit.SECONDS);
		    WebElement Element10 = driverFF.findElement(By.xpath("//*[@id='id_name']"));
		    Element10.sendKeys("Automated_Assignment_FileUpload");
		   String str = driverFF.switchTo().frame("id_introeditor_ifr").getTitle();
		   
		    System.out.println("Its Called :" + str);
		    
		    WebElement Element11 = driverFF.findElement(By.id("tinymce"));
		    Element11.sendKeys(" Assignment One ");
		    driverFF.switchTo().defaultContent();
		    driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		    WebElement Element12 = driverFF.findElement(By.xpath("//*[@id='id_submitbutton2']"));
		    Element12.click();
		    driverFF.manage().timeouts().implicitlyWait(9, TimeUnit.SECONDS);
		    WebElement Element18 = driverFF.findElement(By.xpath("//*[@id='profile_menu']/ul/li/a"));
			Element18.click();
			
			WebElement Element19 = driverFF.findElement(By.xpath("html/body/header/nav/div/div/ul[2]/li[4]/ul/li/ul/li[1]/a"));
			Element19.click();
			driverFF.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
			WebElement Element20 = driverFF.findElement(By.xpath("/html/body/header/nav/div/div/ul/li[2]/a"));
			Element20.click();
			driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			WebElement Element21 = driverFF.findElement(By.xpath("//*[@id='username']"));
			WebElement Element22 = driverFF.findElement(By.xpath("//*[@id='password']"));
			WebElement Element23 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));
			Element21.sendKeys("autostudent01");
			Element22.sendKeys("autoqa1+");
			Element23.click();
			WebElement Element24 = driverFF.findElement(By.xpath("//*[@id='inst714']/div[2]/div[1]/div[1]/a/h2"));
			Element24.click();
			WebElement Element27 = driverFF.findElement(By.xpath("//*[@id='section-1']/div[3]/h3"));
		 	Element27.click();
		 	driverFF.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
		    WebElement Element25 = driverFF.findElement(By.xpath("//span[contains(., 'Automated_Assignment_FileUpload')]"));
		    Element25.click();
		    driverFF.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS); 
  }
}
