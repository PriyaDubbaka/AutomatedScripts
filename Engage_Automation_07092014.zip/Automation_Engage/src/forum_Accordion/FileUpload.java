package forum_Accordion;

import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FileUpload {
  @Test
  public void LoginAsStudent_ManagePrivateFiles() {
	  WebDriver driverFF= new FirefoxDriver();

	  driverFF.navigate().to("https://qa.engagelms.com/learn/my/");

	  WebElement Element1 = driverFF.findElement(By.xpath("//*[@id='username']"));
	  WebElement Element2 = driverFF.findElement(By.xpath("//*[@id='password']"));
	  WebElement Element3 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));

	  Element1.sendKeys("autostudent01");
	  Element2.sendKeys("autoqa1+");
	  Element3.click();
	  driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);


	  WebElement Element4 = driverFF.findElement(By.xpath("//*[@id='inst7']/div[2]/div[2]/form/div/input[1]"));
	  Element4.click();
	  WebElement Element5 = driverFF.findElement(By.className("fp-btn-add"));

	  Element5.click();
	  driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	  WebElement Element5_1 = driverFF.findElement(By.xpath("//ul[@class='fp-list']/li[2]"));
	  Element5_1.click();

	  driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	  WebElement Element6 = driverFF.findElement(By.xpath("html/body/div[6]/div[2]/div/div[2]/div/div[2]/div[2]/div/div/form/table/tbody/tr[1]/td[2]/input"));
	     Element6.click();
	    
	     
	     try {
	     	String[] commands = new String[]{};
	     	commands = new String[]{"C:\\Users\\dubbaka.priya\\Documents\\auto1.exe"}; //location of the autoit executable
	     	Runtime.getRuntime().exec(commands);
	     	}
	     	catch (IOException e) {
	     	
	     	 System.out.println(e.getMessage());
	     	}
	     driverFF.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	     try {
	  		Thread.sleep(5000);
	  	} catch (InterruptedException e) {
	  		// TODO Auto-generated catch block
	  		e.printStackTrace();
	  	}
	    WebElement Element8 = driverFF.findElement(By.xpath("/html/body/div[6]/div[2]/div/div[2]/div/div[2]/div[2]/div/div/div/button"));
	   
	    Element8.click();
	    try {
	  		Thread.sleep(10000);
	  	} catch (InterruptedException e) {
	  		// TODO Auto-generated catch block
	  		e.printStackTrace();
	  	}
	  WebElement Element9 = driverFF.findElement(By.xpath("//*[@id='id_submitbutton']"));
	    
	    Element9.click();


	   if (driverFF.getPageSource().contains("Debug")) 
	   {
	  	 System.out.println("ERROR");
	  	
	   }
	   if (driverFF.getPageSource().contains("Stack trace")) 
	   {
	  	 System.out.println("ERROR");
	  	
	   }
	   }

  }

