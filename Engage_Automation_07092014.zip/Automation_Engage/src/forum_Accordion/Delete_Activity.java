package forum_Accordion;

import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Delete_Activity {
  @Test
  public void FacultyLogin_Delete() {
	  WebDriver driverFF= new FirefoxDriver();
		
		driverFF.navigate().to("https://qa.engagelms.com/learn/my/");

		WebElement Element1 = driverFF.findElement(By.xpath("//*[@id='username']"));
		WebElement Element2 = driverFF.findElement(By.xpath("//*[@id='password']"));
		WebElement Element3 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));

		Element1.sendKeys("autofaculty01");
		Element2.sendKeys("autoqa1+");
		Element3.click();
		driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		 
		if (driverFF.getPageSource().contains("Debug")) 
		   {
		  	 System.out.println("ERROR");
		  	
		   }
		   if (driverFF.getPageSource().contains("Stack trace")) 
		   {
		  	 System.out.println("ERROR");
		  	
		   }
		WebElement Element4 = driverFF.findElement(By.xpath("//*[@id='inst2603']/div[2]/div[1]/div[1]/a/h2"));
		Element4.click();
		WebElement Element5 = driverFF.findElement(By.xpath("html/body/header/nav/div/div/ul[2]/li[3]/div/form/div/input[1]"));
		Element5.click();
		
		driverFF.manage().timeouts().implicitlyWait(9, TimeUnit.SECONDS);
		WebElement Element6 = driverFF.findElement(By.xpath("//*[@id='action-menu-toggle-10']"));
		driverFF.manage().timeouts().implicitlyWait(9, TimeUnit.SECONDS);
		Element6.click();
		driverFF.manage().timeouts().implicitlyWait(9, TimeUnit.SECONDS);
		
		WebElement Element7 = driverFF.findElement(By.xpath("//*[@id='actionmenuaction-72']"));
		driverFF.manage().timeouts().implicitlyWait(9, TimeUnit.SECONDS);
		Element7.click();
		
		driverFF.switchTo().alert().accept();
		System.out.println("Item Deleted!!");
		
		WebElement Element8 = driverFF.findElement(By.xpath("//*[@id='profile_menu']/ul/li/a"));
					Element8.click();
					WebElement Element9 = driverFF.findElement(By.xpath("html/body/header/nav/div/div/ul[2]/li[4]/ul/li/ul/li[1]/a"));
					Element9.click();
					driverFF.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
					WebElement Element10 = driverFF.findElement(By.xpath("/html/body/header/nav/div/div/ul/li[2]/a"));
					Element10.click();
					driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
					WebElement Element12 = driverFF.findElement(By.xpath("//*[@id='username']"));
					WebElement Element13 = driverFF.findElement(By.xpath("//*[@id='password']"));
					WebElement Element14 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));
					Element12.sendKeys("autostudent01");
					Element13.sendKeys("autoqa1+");
					Element14.click();
					driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
					WebElement Element11 = driverFF.findElement(By.xpath("//*[@id='inst2683']/div[2]/div[1]/div[1]/a/h2"));
					Element11.click();
					driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
					WebElement Element27 = driverFF.findElement(By.xpath("//*[@id='section-0']/div[3]/h3"));
				 	Element27.click();
				 	driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
					if(! driverFF.getPageSource().contains("ONE_D"))
					{System.out.println("Delete Verified");}
					
					try {
						Thread.sleep(10000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		//driverFF.quit();
				

  }
}
