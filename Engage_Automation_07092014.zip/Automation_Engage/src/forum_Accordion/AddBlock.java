package forum_Accordion;

import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
public class AddBlock {
  @Test
  public void AddCoursesBlock() {
	  WebDriver driverFF= new FirefoxDriver();
		
		driverFF.navigate().to("https://qa.engagelms.com/learn/my/");

		WebElement Element1 = driverFF.findElement(By.xpath("//*[@id='username']"));
		WebElement Element2 = driverFF.findElement(By.xpath("//*[@id='password']"));
		WebElement Element3 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));

		Element1.sendKeys("autofaculty01");
		Element2.sendKeys("autoqa1+");
		Element3.click();
		driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		driverFF.manage().window().maximize();
		driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		WebElement Element4 = driverFF.findElement(By.xpath("//*[@id='inst2603']/div[2]/div[1]/div[1]/a/h2"));
		Element4.click();
		WebElement Element5 = driverFF.findElement(By.xpath("html/body/header/nav/div/div/ul[2]/li[3]/div/form/div/input[1]"));
		Element5.click();
		driverFF.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		WebElement Element6 = driverFF.findElement(By.xpath("html/body/div[4]/div[2]/div/div/aside/div/div[2]/div/form/div/select"));
		Element6.click();
		Select clickThis = new Select(Element6); 
		// Make a Selection from the listbox here, this test is to test for 6 topics in the course.
		clickThis.selectByIndex(10);
		
		driverFF.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement Element7 = driverFF.findElement(By.xpath("//h2[contains(., 'My courses')]"));
		Boolean Courses1 = Element7.isDisplayed();
		
		if (Courses1 == true)
		{System.out.println("My Courses Verified - Faculty ");}
		
		 WebElement Element18 = driverFF.findElement(By.xpath("//*[@id='profile_menu']/ul/li/a"));
			Element18.click();
			WebElement Element19 = driverFF.findElement(By.xpath("html/body/header/nav/div/div/ul[2]/li[4]/ul/li/ul/li[1]/a"));
			Element19.click();
			driverFF.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
			WebElement Element20 = driverFF.findElement(By.xpath("/html/body/header/nav/div/div/ul/li[2]/a"));
			Element20.click();
			driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			WebElement Element21 = driverFF.findElement(By.xpath("//*[@id='username']"));
			WebElement Element22 = driverFF.findElement(By.xpath("//*[@id='password']"));
			WebElement Element23 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));
			Element21.sendKeys("autostudent01");
			Element22.sendKeys("autoqa1+");
			Element23.click();
			WebElement Element24 = driverFF.findElement(By.xpath("//*[@id='inst2683']/div[2]/div[1]/div[1]/a/h2"));
			Element24.click();
			 driverFF.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			 WebElement Element27 = driverFF.findElement(By.xpath("//h2[contains(., 'My courses')]"));
				Boolean Courses2 = Element27.isDisplayed();
				if(Courses2 == true)
				{System.out.println("My Courses Verified - Student");}
					
				 driverFF.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				WebElement Element28 = driverFF.findElement(By.xpath("//*[@id='profile_menu']/ul/li/a"));
				Element28.click();
				WebElement Element29 = driverFF.findElement(By.xpath("html/body/header/nav/div/div/ul[2]/li[4]/ul/li/ul/li[1]/a"));
				Element29.click();
				driverFF.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
				WebElement Element30 = driverFF.findElement(By.xpath("/html/body/header/nav/div/div/ul/li[2]/a"));
				Element30.click();
				driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
				WebElement Element31 = driverFF.findElement(By.xpath("//*[@id='username']"));
				WebElement Element32 = driverFF.findElement(By.xpath("//*[@id='password']"));
				WebElement Element33 = driverFF.findElement(By.xpath("//*[@id='loginbtn']"));
				Element31.sendKeys("autofaculty01");
				Element32.sendKeys("autoqa1+");
				Element33.click();
				driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
				
				driverFF.manage().window().maximize();
				driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
				WebElement Element44 = driverFF.findElement(By.xpath("//*[@id='inst2603']/div[2]/div[1]/div[1]/a/h2"));
				Element44.click();
				WebElement Element45 = driverFF.findElement(By.xpath("html/body/header/nav/div/div/ul[2]/li[3]/div/form/div/input[1]"));
				Element45.click();
				WebElement Element34 = driverFF.findElement(By.xpath("html/body/div[4]/div[2]/div/div/aside/div[2]/div[1]/div/div[2]/ul[1]/li[2]/a/img"));
				Element34.click();
				driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
				WebElement Element35= driverFF.findElement(By.xpath("html/body/div[4]/div[2]/div/div/aside/div[2]/div[1]/div/div[2]/ul[2]/li[4]/a/span"));
				Element35.click();
				driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
				WebElement Element36= driverFF.findElement(By.xpath("html/body/div[4]/div/section/div[2]/div/div/div[1]/form/div/input[1]"));
				Element36.click();
				driverFF.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
				driverFF.close();
				driverFF.quit();
				
  }
}
